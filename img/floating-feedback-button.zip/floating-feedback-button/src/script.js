$(window).load( function() {
	$(".nps.floatingActionButton").click( function() {
		$(".nps.formContainer").addClass("transitionIn").removeClass("transitionOut");
		$(this).removeClass("thankYou")
	});
	
	$(".nps.close").click( function() {
		$(".nps.formContainer").addClass("transitionOut").removeClass("transitionIn");
		$(".nps.floatingActionButton").text("🎤 Feedback").removeClass("thankYou");
	});
	
	$(".nps.button").click( function() {
		setTimeout(function(){
			$(".nps.floatingActionButton").fadeOut();	
		}, 3000);
		$(".nps.floatingActionButton").addClass("thankYou").text("Thank you ❤️");
		$(".nps.formContainer").addClass("transitionOut").removeClass("transitionIn");
	});
});